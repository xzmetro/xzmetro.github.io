package org.simplecity.mod.block;

import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_2753;
import net.minecraft.class_3726;
import org.jetbrains.annotations.NotNull;

public class VerticalSlabBlock extends class_2383 {
    public static final class_2753 FACING = class_2383.field_11177;
    public static final class_2746 DOUBLE = class_2746.method_11825("double");

    private static final class_265 NORTH_SHAPE = class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 16.0, 8.0);
    private static final class_265 SOUTH_SHAPE = class_2248.method_9541(0.0, 0.0, 8.0, 16.0, 16.0, 16.0);
    private static final class_265 EAST_SHAPE = class_2248.method_9541(8.0, 0.0, 0.0, 16.0, 16.0, 16.0);
    private static final class_265 WEST_SHAPE = class_2248.method_9541(0.0, 0.0, 0.0, 8.0, 16.0, 16.0);
    private static final class_265 FULL_SHAPE = class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 16.0, 16.0);

    public VerticalSlabBlock(class_2251 properties) {
        super(properties);
        this.method_9590(this.field_10647.method_11664()
                .method_11657(field_11177, class_2350.field_11043)
                .method_11657(DOUBLE, false));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_11177, DOUBLE);
    }

    @Override
    @SuppressWarnings("deprecation")
    public @NotNull class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        if (state.method_11654(DOUBLE)) {
            return FULL_SHAPE;
        }
        return switch (state.method_11654(field_11177)) {
            case field_11043 -> NORTH_SHAPE;
            case field_11035 -> SOUTH_SHAPE;
            case field_11034 -> EAST_SHAPE;
            case field_11039 -> WEST_SHAPE;
            default -> class_2248.method_9541(0, 0, 0, 0, 0, 0);
        };
    }

    @Override
    @SuppressWarnings("deprecation")
    public @NotNull class_265 method_9549(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return this.method_9530(state, level, pos, context);
    }

    @Override
    public class_2680 method_9605(class_1750 context) {
        class_2338 pos = context.method_8037();
        class_2680 currentState = context.method_8045().method_8320(pos);
        class_2350 clickedSide = context.method_8038();
        class_2350 newFacing = context.method_8042().method_10153();

        if (currentState.method_26204() == this && !currentState.method_11654(DOUBLE)) {
            class_2350 existingFacing = currentState.method_11654(field_11177);
            if (clickedSide == existingFacing) {
                return currentState.method_11657(DOUBLE, true);
            }
        }

        return this.method_9564().method_11657(field_11177, newFacing).method_11657(DOUBLE, false);
    }

    @Override
    @SuppressWarnings("deprecation")
    public boolean method_9616(class_2680 state, class_1750 context) {
        // 双板不可替换
        if (state.method_11654(DOUBLE)) {
            return false;
        }

        // 如果手持的是竖半砖
        if (context.method_8041().method_7909() == this.method_8389()) {
            class_2350 existingFacing = state.method_11654(field_11177);
            class_2350 clickedSide = context.method_8038();
            // 只有点击的面是朝向的方向才允许替换（即可以合并）
            if (clickedSide == existingFacing) {
                return true;
            }
        }

        return super.method_9616(state, context);
    }
}