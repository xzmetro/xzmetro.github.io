package org.simplecity.mod.mixin.client;

import net.minecraft.class_310;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_437.class)
public class ScreenCursorMixin {
    @Unique
    private long lastCursor = -1;
    @Unique
    private boolean lastHovered = false;

    @Inject(method = "render", at = @At("HEAD"))
    private void onRender(CallbackInfo ci) {
        class_437 screen = (class_437) (Object) this;
        class_310 client = class_310.method_1551();

        if (client.field_1755 == screen) {
            double mouseX = client.field_1729.method_1603() * (double) client.method_22683().method_4486() / (double) client.method_22683().method_4480();
            double mouseY = client.field_1729.method_1604() * (double) client.method_22683().method_4502() / (double) client.method_22683().method_4507();

            boolean hoverButton = false;
            for (var child : screen.method_25396()) {
                if (child instanceof class_4185 button && button.method_25405(mouseX, mouseY)) {
                    hoverButton = true;
                    break;
                }
            }

            long windowHandle = client.method_22683().method_4490();

            if (hoverButton) {
                if (!lastHovered) {
                    long cursor = GLFW.glfwCreateStandardCursor(GLFW.GLFW_HAND_CURSOR);
                    if (cursor != 0) {
                        GLFW.glfwSetCursor(windowHandle, cursor);
                        if (lastCursor != -1 && lastCursor != cursor) {
                            GLFW.glfwDestroyCursor(lastCursor);
                        }
                        lastCursor = cursor;
                    }
                    lastHovered = true;
                }
            } else {
                if (lastHovered) {
                    long cursor = GLFW.glfwCreateStandardCursor(GLFW.GLFW_ARROW_CURSOR);
                    if (cursor != 0) {
                        GLFW.glfwSetCursor(windowHandle, cursor);
                        if (lastCursor != -1 && lastCursor != cursor) {
                            GLFW.glfwDestroyCursor(lastCursor);
                        }
                        lastCursor = cursor;
                    }
                    lastHovered = false;
                }
            }
        }
    }
}