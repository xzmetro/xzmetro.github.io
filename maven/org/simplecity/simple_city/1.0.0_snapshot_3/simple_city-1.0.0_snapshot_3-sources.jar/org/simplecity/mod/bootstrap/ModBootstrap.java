package org.simplecity.mod.bootstrap;

import org.simplecity.mod.block.ModBlocks;
import org.simplecity.mod.creativetab.ModCreativeTabs;
import org.simplecity.mod.main.SimpleCity;
import org.simplecity.mod.sound.ModSounds;

public class ModBootstrap {
    public static void bootstrap() {
        ModBanner.print();
        ModSounds.initialize();
        ModBlocks.initialize();
        ModCreativeTabs.initialize();
        SimpleCity.LOGGER.warn("[Simple City] Known bug: fire_extinguisher_cabinet#opened=true model broken (fix pending)");
        SimpleCity.LOGGER.info("[Simple City] Initialized successfully");
    }
}
