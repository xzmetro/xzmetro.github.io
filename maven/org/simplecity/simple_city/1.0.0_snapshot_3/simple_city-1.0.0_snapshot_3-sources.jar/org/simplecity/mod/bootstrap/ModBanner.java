package org.simplecity.mod.bootstrap;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_155;
import org.simplecity.mod.main.SimpleCity;

import java.lang.management.ManagementFactory;
import java.util.List;

public class ModBanner {
    public static String getVersionString() {
        String minecraftVersion = class_155.method_16673().method_48019();
        String loaderVersion = FabricLoader.getInstance().getModContainer("fabricloader").orElseThrow().getMetadata().getVersion().getFriendlyString();
        String modVersion = SimpleCity.MOD_VERSION;
        return String.format("[Simple City] Runtime: Minecraft %s, Fabric Loader %s, Simple City %s", minecraftVersion, loaderVersion, modVersion);
    }
    public static void print() {
        List<String> arguments = ManagementFactory.getRuntimeMXBean().getInputArguments();
        SimpleCity.LOGGER.info("  ____  _                 _         ____ _ _");
        SimpleCity.LOGGER.info(" / ___|(_)_ __ ___  _ __ | | ___   / ___(_) |_ _   _");
        SimpleCity.LOGGER.info(" \\___ \\| | '_ ` _ \\| '_ \\| |/ _ \\ | |   | | __| | | |");
        SimpleCity.LOGGER.info("  ___) | | | | | | | |_) | |  __/ | |___| | |_| |_| |");
        SimpleCity.LOGGER.info(" |____/|_|_| |_| |_| .__/|_|\\___|  \\____|_|\\__|\\__, |");
        SimpleCity.LOGGER.info("                         |_|                    |___/");
        SimpleCity.LOGGER.info(getVersionString());
        SimpleCity.LOGGER.debug("[Simple City] JVM arguments: {}", arguments);
    }
}
