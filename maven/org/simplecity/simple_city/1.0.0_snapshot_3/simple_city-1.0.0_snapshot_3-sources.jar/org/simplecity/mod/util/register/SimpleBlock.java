package org.simplecity.mod.util.register;

import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import org.simplecity.mod.main.SimpleCity;

public final class SimpleBlock {
    private SimpleBlock() {
    }

    public static <T extends class_2248> T register(String name, T block, boolean shouldRegisterItem) {
        class_2960 id = new class_2960(SimpleCity.MOD_ID, name);
        if (shouldRegisterItem) {
            class_2378.method_10230(class_7923.field_41178, id, new class_1747(block, new class_1792.class_1793()));
        }
        return class_2378.method_10230(class_7923.field_41175, id, block);
    }
}