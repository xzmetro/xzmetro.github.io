package org.simplecity.mod.util.register;

import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import org.simplecity.mod.item.TooltipBlockItem;
import org.simplecity.mod.main.SimpleCity;

public final class TooltipBlock {
    private TooltipBlock() {
    }

    public static <T extends class_2248> T register(String name, T block, String... tooltips) {
        class_2960 id = new class_2960(SimpleCity.MOD_ID, name);
        class_2378.method_10230(class_7923.field_41178, id, new TooltipBlockItem(block, new class_1792.class_1793(), tooltips));
        class_2378.method_10230(class_7923.field_41175, id, block);
        return block;
    }
}
