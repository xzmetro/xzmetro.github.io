package org.simplecity.mod.util.register;

import org.simplecity.mod.item.TooltipBlockItem;

import static org.simplecity.mod.util.Constants.getId;

import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public final class TooltipBlock {
    private TooltipBlock() {
    }

    public static <T extends class_2248> T register(String name, T block, String... tooltips) {
        class_2960 id = getId(name);
        class_2378.method_10230(class_7923.field_41178, id, new TooltipBlockItem(block, new class_1792.class_1793(), tooltips));
        class_2378.method_10230(class_7923.field_41175, id, block);
        return block;
    }
}
