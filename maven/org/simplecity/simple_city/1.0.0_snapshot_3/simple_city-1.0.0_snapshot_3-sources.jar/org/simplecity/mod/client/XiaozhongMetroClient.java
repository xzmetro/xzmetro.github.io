package org.simplecity.mod.client;

import net.fabricmc.api.ClientModInitializer;
import org.simplecity.mod.main.SimpleCity;

public class XiaozhongMetroClient implements ClientModInitializer {

    @Override
	public void onInitializeClient() {
		SimpleCity.LOGGER.info("[Xiaozhong's Metro] Mod Client Loaded!");
	}
}