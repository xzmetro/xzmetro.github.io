package org.simplecity.mod.main;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.simplecity.mod.bootstrap.ModBootstrap;

public class SimpleCity implements ModInitializer {
    public static final String MOD_ID = "simple_city";
    public static final String MOD_VERSION = "1.0.0_snapshot_3";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModBootstrap.bootstrap();
    }
}