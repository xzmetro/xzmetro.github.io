package org.simplecity.mod.item;

import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2561;

public class TooltipBlockItem extends class_1747 {
    private final String[] tooltips;

    public TooltipBlockItem(class_2248 block, class_1793 properties, String[] tooltips) {
        super(block, properties);
        this.tooltips = tooltips;
    }

    @Override
    public void method_7851(class_1799 stack, @Nullable class_1937 level, List<class_2561> components, class_1836 flag) {
        super.method_7851(stack, level, components, flag);
        for (String tooltip : tooltips) {
            components.add(class_2561.method_43471(tooltip));
        }
    }
}
