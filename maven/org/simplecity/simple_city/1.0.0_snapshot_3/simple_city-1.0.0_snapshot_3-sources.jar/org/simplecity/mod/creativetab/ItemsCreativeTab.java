package org.simplecity.mod.creativetab;

import org.simplecity.mod.block.ModBlocks;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import org.simplecity.mod.main.SimpleCity;

public class ItemsCreativeTab {
    public static final class_5321<class_1761> ITEMS_CREATIVE_TAB_KEY = class_5321.method_29179(class_7923.field_44687.method_30517(), new class_2960(SimpleCity.MOD_ID, "items"));

    public static final class_1761 ITEMS_CREATIVE_TAB = FabricItemGroup.builder()
            .method_47320(() -> new class_1799(ModBlocks.WUZHOU_METRO_LOGO_1_3))
            .method_47321(class_2561.method_43471("itemGroup.simple_city.items"))
            .method_47317((params, output) -> {
                output.method_45421(ModBlocks.WUZHOU_METRO_LOGO_1_3);
                output.method_45421(ModBlocks.WUZHOU_METRO_LOGO_3_3);
                output.method_45421(ModBlocks.FIRE_EXTINGUISHER);
                output.method_45421(ModBlocks.FIRE_EXTINGUISHER_CABINET);
                output.method_45421(ModBlocks.TRAIN_DEPARTURE_BELL);
                output.method_45421(ModBlocks.PARKING_BARRIER_LEFT);
                output.method_45421(ModBlocks.PARKING_BARRIER_MIDDLE);
                output.method_45421(ModBlocks.PARKING_BARRIER_RIGHT);
                output.method_45421(ModBlocks.PARKING_BARRIER_BRACKET);
                output.method_45421(ModBlocks.APG_RAILING);
                output.method_45421(ModBlocks.METRO_BENCHMARK_SIGN);
                output.method_45421(ModBlocks.LOW_STATION_SIGN);
                output.method_45421(ModBlocks.HIGH_STATION_SIGN);
                output.method_45421(ModBlocks.GLOWING_SLAB);
            })
            .method_47324();

    public static void initialize() {
        class_2378.method_39197(class_7923.field_44687, ITEMS_CREATIVE_TAB_KEY, ITEMS_CREATIVE_TAB);
    }
}
