package org.xzmetro.mod.util;

import net.minecraft.class_2960;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Constants {
    public static final String MOD_ID = "xzmetro";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static class_2960 getId(String path) {
        return new class_2960(MOD_ID, path);
    }
}
