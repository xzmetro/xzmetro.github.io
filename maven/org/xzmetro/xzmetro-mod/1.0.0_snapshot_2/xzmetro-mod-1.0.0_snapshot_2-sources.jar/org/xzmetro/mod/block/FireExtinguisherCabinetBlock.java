package org.xzmetro.mod.block;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_2753;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import org.jetbrains.annotations.NotNull;

public class FireExtinguisherCabinetBlock extends class_2383 {
    public static final class_2753 FACING = class_2383.field_11177;
    public static final class_2746 OPEN = class_2746.method_11825("open");
    private static final class_265 SHAPE_NORTH = class_2248.method_9541(2.0, 0.0, 9.0, 14.0, 16.0, 16.0);
    private static final class_265 SHAPE_SOUTH = class_2248.method_9541(2.0, 0.0, 0.0, 14.0, 16.0, 7.0);
    private static final class_265 SHAPE_WEST = class_2248.method_9541(9.0, 0.0, 2.0, 16.0, 16.0, 14.0);
    private static final class_265 SHAPE_EAST = class_2248.method_9541(0.0, 0.0, 2.0, 7.0, 16.0, 14.0);

    public FireExtinguisherCabinetBlock(class_2251 properties) {
        super(properties);
        this.method_9590(this.field_10647.method_11664().method_11657(field_11177, class_2350.field_11043).method_11657(OPEN, true));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_11177, OPEN);
    }

    @Override
    public class_2680 method_9605(class_1750 context) {
        return (class_2680) this.method_9564().method_11657(field_11177, context.method_8042().method_10153());
    }

    @Override
    @SuppressWarnings("deprecation")
    public @NotNull class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        class_2350 facing = state.method_11654(field_11177);
        return switch (facing) {
            case field_11043 -> SHAPE_NORTH;
            case field_11035 -> SHAPE_SOUTH;
            case field_11039 -> SHAPE_WEST;
            case field_11034 -> SHAPE_EAST;
            default -> class_2248.method_9541(0.0, 0.0, 0.0, 0.0, 0.0, 0.0);
        };
    }

    @Override
    @SuppressWarnings("deprecation")
    public @NotNull class_1269 method_9534(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        boolean currentOpen = state.method_11654(OPEN);
        level.method_8652(pos, (class_2680) state.method_11657(OPEN, !currentOpen), 3);
        return class_1269.field_5812;
    }
}