package org.xzmetro.mod.block;

import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2753;
import net.minecraft.class_3726;
import org.jetbrains.annotations.NotNull;

public class TactilePavingBlock extends class_2383 {
    public static final class_2753 FACING = class_2383.field_11177;

    private static final class_265 SHAPE_X = class_259.method_17786(
            class_2248.method_9541(0, 0, 0, 16, 1, 16),
            class_2248.method_9541(2, 1, 1, 3, 2, 15),
            class_2248.method_9541(4, 1, 1, 5, 2, 15),
            class_2248.method_9541(6, 1, 1, 7, 2, 15),
            class_2248.method_9541(9, 1, 1, 10, 2, 15),
            class_2248.method_9541(11, 1, 1, 12, 2, 15),
            class_2248.method_9541(13, 1, 1, 14, 2, 15)
    );
    private static final class_265 SHAPE_Z = class_259.method_17786(
            class_2248.method_9541(0, 0, 0, 16, 1, 16),
            class_2248.method_9541(1, 1, 2, 15, 2, 3),
            class_2248.method_9541(1, 1, 4, 15, 2, 5),
            class_2248.method_9541(1, 1, 6, 15, 2, 7),
            class_2248.method_9541(1, 1, 9, 15, 2, 10),
            class_2248.method_9541(1, 1, 11, 15, 2, 12),
            class_2248.method_9541(1, 1, 13, 15, 2, 14)
    );

    public TactilePavingBlock(class_2251 properties) {
        super(properties);
        this.method_9590(this.field_10647.method_11664().method_11657(field_11177, class_2350.field_11043));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_11177);
    }

    @Override
    public class_2680 method_9605(class_1750 context) {
        return this.method_9564().method_11657(field_11177, context.method_8042().method_10153());
    }

    @Override
    @SuppressWarnings("deprecation")
    public @NotNull class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        class_2350 facing = state.method_11654(field_11177);
        return switch (facing) {
            case field_11043, field_11035 -> SHAPE_X;
            case field_11034, field_11039 -> SHAPE_Z;
            default -> class_2248.method_9541(0, 0, 0, 0, 0, 0);
        };
    }
}