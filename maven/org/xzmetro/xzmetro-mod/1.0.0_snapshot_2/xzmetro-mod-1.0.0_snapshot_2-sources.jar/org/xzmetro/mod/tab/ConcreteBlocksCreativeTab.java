package org.xzmetro.mod.tab;

import org.xzmetro.mod.block.ModBlocks;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_5321;
import net.minecraft.class_7923;

import static org.xzmetro.mod.util.Constants.getId;

public class ConcreteBlocksCreativeTab {
    public static final class_5321<class_1761> CONCRETE_BLOCKS_CREATIVE_TAB_KEY = class_5321.method_29179(class_7923.field_44687.method_30517(), getId("concrete_blocks"));

    public static final class_1761 CONCRETE_BLOCKS_CREATIVE_TAB = FabricItemGroup.builder()
            .method_47320(() -> new class_1799(ModBlocks.WHITE_CONCRETE_STAIRS))
            .method_47321(class_2561.method_43471("itemGroup.xzmetro.concrete_blocks"))
            .method_47317((params, output) -> {
                output.method_45421(ModBlocks.WHITE_CONCRETE_SLAB);
                output.method_45421(ModBlocks.ORANGE_CONCRETE_SLAB);
                output.method_45421(ModBlocks.MAGENTA_CONCRETE_SLAB);
                output.method_45421(ModBlocks.LIGHT_BLUE_CONCRETE_SLAB);
                output.method_45421(ModBlocks.YELLOW_CONCRETE_SLAB);
                output.method_45421(ModBlocks.LIME_CONCRETE_SLAB);
                output.method_45421(ModBlocks.PINK_CONCRETE_SLAB);
                output.method_45421(ModBlocks.GRAY_CONCRETE_SLAB);
                output.method_45421(ModBlocks.LIGHT_GRAY_CONCRETE_SLAB);
                output.method_45421(ModBlocks.CYAN_CONCRETE_SLAB);
                output.method_45421(ModBlocks.PURPLE_CONCRETE_SLAB);
                output.method_45421(ModBlocks.BLUE_CONCRETE_SLAB);
                output.method_45421(ModBlocks.BROWN_CONCRETE_SLAB);
                output.method_45421(ModBlocks.GREEN_CONCRETE_SLAB);
                output.method_45421(ModBlocks.RED_CONCRETE_SLAB);
                output.method_45421(ModBlocks.BLACK_CONCRETE_SLAB);
                output.method_45421(ModBlocks.WHITE_CONCRETE_STAIRS);
                output.method_45421(ModBlocks.ORANGE_CONCRETE_STAIRS);
                output.method_45421(ModBlocks.MAGENTA_CONCRETE_STAIRS);
                output.method_45421(ModBlocks.LIGHT_BLUE_CONCRETE_STAIRS);
                output.method_45421(ModBlocks.YELLOW_CONCRETE_STAIRS);
                output.method_45421(ModBlocks.LIME_CONCRETE_STAIRS);
                output.method_45421(ModBlocks.PINK_CONCRETE_STAIRS);
                output.method_45421(ModBlocks.GRAY_CONCRETE_STAIRS);
                output.method_45421(ModBlocks.LIGHT_GRAY_CONCRETE_STAIRS);
                output.method_45421(ModBlocks.CYAN_CONCRETE_STAIRS);
                output.method_45421(ModBlocks.PURPLE_CONCRETE_STAIRS);
                output.method_45421(ModBlocks.BLUE_CONCRETE_STAIRS);
                output.method_45421(ModBlocks.BROWN_CONCRETE_STAIRS);
                output.method_45421(ModBlocks.GREEN_CONCRETE_STAIRS);
                output.method_45421(ModBlocks.RED_CONCRETE_STAIRS);
                output.method_45421(ModBlocks.BLACK_CONCRETE_STAIRS);
                output.method_45421(ModBlocks.WHITE_CONCRETE_VERTICAL_SLAB);
                output.method_45421(ModBlocks.ORANGE_CONCRETE_VERTICAL_SLAB);
                output.method_45421(ModBlocks.MAGENTA_CONCRETE_VERTICAL_SLAB);
                output.method_45421(ModBlocks.LIGHT_BLUE_CONCRETE_VERTICAL_SLAB);
                output.method_45421(ModBlocks.YELLOW_CONCRETE_VERTICAL_SLAB);
                output.method_45421(ModBlocks.LIME_CONCRETE_VERTICAL_SLAB);
                output.method_45421(ModBlocks.PINK_CONCRETE_VERTICAL_SLAB);
                output.method_45421(ModBlocks.GRAY_CONCRETE_VERTICAL_SLAB);
                output.method_45421(ModBlocks.LIGHT_GRAY_CONCRETE_VERTICAL_SLAB);
                output.method_45421(ModBlocks.CYAN_CONCRETE_VERTICAL_SLAB);
                output.method_45421(ModBlocks.PURPLE_CONCRETE_VERTICAL_SLAB);
                output.method_45421(ModBlocks.BLUE_CONCRETE_VERTICAL_SLAB);
                output.method_45421(ModBlocks.BROWN_CONCRETE_VERTICAL_SLAB);
                output.method_45421(ModBlocks.GREEN_CONCRETE_VERTICAL_SLAB);
                output.method_45421(ModBlocks.RED_CONCRETE_VERTICAL_SLAB);
                output.method_45421(ModBlocks.BLACK_CONCRETE_VERTICAL_SLAB);
            })
            .method_47324();

    public static void initialize() {
        class_2378.method_39197(class_7923.field_44687, CONCRETE_BLOCKS_CREATIVE_TAB_KEY, CONCRETE_BLOCKS_CREATIVE_TAB);
    }
}
