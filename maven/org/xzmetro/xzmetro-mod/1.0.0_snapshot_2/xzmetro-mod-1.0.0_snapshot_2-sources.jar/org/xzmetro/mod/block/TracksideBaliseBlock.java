package org.xzmetro.mod.block;

import net.minecraft.class_2248;

public class TracksideBaliseBlock extends class_2248 {
    public TracksideBaliseBlock(class_2251 properties) {
        super(properties);
    }
}
