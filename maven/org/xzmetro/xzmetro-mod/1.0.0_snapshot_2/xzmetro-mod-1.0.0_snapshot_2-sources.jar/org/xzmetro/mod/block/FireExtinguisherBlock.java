package org.xzmetro.mod.block;

import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2753;
import net.minecraft.class_3726;
import org.jetbrains.annotations.NotNull;

public class FireExtinguisherBlock extends class_2383 {
    public static final class_2753 FACING = class_2383.field_11177;
    private static final class_265 SHAPE = class_2248.method_9541(5.0, 0.0, 5.0, 11.0, 17.0, 11.0);

    public FireExtinguisherBlock(class_2251 properties) {
        super(properties);
        this.method_9590(this.field_10647.method_11664().method_11657(field_11177, class_2350.field_11043));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_11177);
    }

    @Override
    public class_2680 method_9605(class_1750 context) {
        return this.method_9564().method_11657(field_11177, context.method_8042().method_10153());
    }

    @Override
    @SuppressWarnings("deprecation")
    public @NotNull class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return SHAPE;
    }
}
