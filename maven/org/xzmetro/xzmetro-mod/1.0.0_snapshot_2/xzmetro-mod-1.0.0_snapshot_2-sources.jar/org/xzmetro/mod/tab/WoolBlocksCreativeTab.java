package org.xzmetro.mod.tab;

import org.xzmetro.mod.block.ModBlocks;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_5321;
import net.minecraft.class_7923;

import static org.xzmetro.mod.util.Constants.getId;

public class WoolBlocksCreativeTab {
    public static final class_5321<class_1761> WOOL_BLOCKS_CREATIVE_TAB_KEY = class_5321.method_29179(class_7923.field_44687.method_30517(), getId("wool_blocks"));

    public static final class_1761 WOOL_BLOCKS_CREATIVE_TAB = FabricItemGroup.builder()
            .method_47320(() -> new class_1799(ModBlocks.WHITE_WOOL_STAIRS))
            .method_47321(class_2561.method_43471("itemGroup.xzmetro.wool_blocks"))
            .method_47317((params, output) -> {
                output.method_45421(ModBlocks.WHITE_WOOL_SLAB);
                output.method_45421(ModBlocks.ORANGE_WOOL_SLAB);
                output.method_45421(ModBlocks.MAGENTA_WOOL_SLAB);
                output.method_45421(ModBlocks.LIGHT_BLUE_WOOL_SLAB);
                output.method_45421(ModBlocks.YELLOW_WOOL_SLAB);
                output.method_45421(ModBlocks.LIME_WOOL_SLAB);
                output.method_45421(ModBlocks.PINK_WOOL_SLAB);
                output.method_45421(ModBlocks.GRAY_WOOL_SLAB);
                output.method_45421(ModBlocks.LIGHT_GRAY_WOOL_SLAB);
                output.method_45421(ModBlocks.CYAN_WOOL_SLAB);
                output.method_45421(ModBlocks.PURPLE_WOOL_SLAB);
                output.method_45421(ModBlocks.BLUE_WOOL_SLAB);
                output.method_45421(ModBlocks.BROWN_WOOL_SLAB);
                output.method_45421(ModBlocks.GREEN_WOOL_SLAB);
                output.method_45421(ModBlocks.RED_WOOL_SLAB);
                output.method_45421(ModBlocks.BLACK_WOOL_SLAB);

                // ===== 羊毛楼梯 =====
                output.method_45421(ModBlocks.WHITE_WOOL_STAIRS);
                output.method_45421(ModBlocks.ORANGE_WOOL_STAIRS);
                output.method_45421(ModBlocks.MAGENTA_WOOL_STAIRS);
                output.method_45421(ModBlocks.LIGHT_BLUE_WOOL_STAIRS);
                output.method_45421(ModBlocks.YELLOW_WOOL_STAIRS);
                output.method_45421(ModBlocks.LIME_WOOL_STAIRS);
                output.method_45421(ModBlocks.PINK_WOOL_STAIRS);
                output.method_45421(ModBlocks.GRAY_WOOL_STAIRS);
                output.method_45421(ModBlocks.LIGHT_GRAY_WOOL_STAIRS);
                output.method_45421(ModBlocks.CYAN_WOOL_STAIRS);
                output.method_45421(ModBlocks.PURPLE_WOOL_STAIRS);
                output.method_45421(ModBlocks.BLUE_WOOL_STAIRS);
                output.method_45421(ModBlocks.BROWN_WOOL_STAIRS);
                output.method_45421(ModBlocks.GREEN_WOOL_STAIRS);
                output.method_45421(ModBlocks.RED_WOOL_STAIRS);
                output.method_45421(ModBlocks.BLACK_WOOL_STAIRS);

                // ===== 羊毛竖半砖 =====
                output.method_45421(ModBlocks.WHITE_WOOL_VERTICAL_SLAB);
                output.method_45421(ModBlocks.ORANGE_WOOL_VERTICAL_SLAB);
                output.method_45421(ModBlocks.MAGENTA_WOOL_VERTICAL_SLAB);
                output.method_45421(ModBlocks.LIGHT_BLUE_WOOL_VERTICAL_SLAB);
                output.method_45421(ModBlocks.YELLOW_WOOL_VERTICAL_SLAB);
                output.method_45421(ModBlocks.LIME_WOOL_VERTICAL_SLAB);
                output.method_45421(ModBlocks.PINK_WOOL_VERTICAL_SLAB);
                output.method_45421(ModBlocks.GRAY_WOOL_VERTICAL_SLAB);
                output.method_45421(ModBlocks.LIGHT_GRAY_WOOL_VERTICAL_SLAB);
                output.method_45421(ModBlocks.CYAN_WOOL_VERTICAL_SLAB);
                output.method_45421(ModBlocks.PURPLE_WOOL_VERTICAL_SLAB);
                output.method_45421(ModBlocks.BLUE_WOOL_VERTICAL_SLAB);
                output.method_45421(ModBlocks.BROWN_WOOL_VERTICAL_SLAB);
                output.method_45421(ModBlocks.GREEN_WOOL_VERTICAL_SLAB);
                output.method_45421(ModBlocks.RED_WOOL_VERTICAL_SLAB);
                output.method_45421(ModBlocks.BLACK_WOOL_VERTICAL_SLAB);
            })
            .method_47324();

    public static void initialize() {
        class_2378.method_39197(class_7923.field_44687, WOOL_BLOCKS_CREATIVE_TAB_KEY, WOOL_BLOCKS_CREATIVE_TAB);
    }
}