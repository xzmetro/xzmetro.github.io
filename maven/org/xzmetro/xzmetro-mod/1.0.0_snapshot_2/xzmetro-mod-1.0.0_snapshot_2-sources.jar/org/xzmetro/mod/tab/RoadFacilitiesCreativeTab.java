package org.xzmetro.mod.tab;

import org.xzmetro.mod.block.ModBlocks;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_5321;
import net.minecraft.class_7923;

import static org.xzmetro.mod.util.Constants.getId;

public class RoadFacilitiesCreativeTab {
    public static final class_5321<class_1761> ROAD_FACILITIES_CREATIVE_TAB_KEY = class_5321.method_29179(class_7923.field_44687.method_30517(), getId("road_facilities"));

    public static final class_1761 ROAD_FACILITIES_CREATIVE_TAB = FabricItemGroup.builder()
            .method_47320(() -> new class_1799(ModBlocks.PLAIN_CONSTRUCTION_BARRIER))
            .method_47321(class_2561.method_43471("itemGroup.xzmetro.road_facilities"))
            .method_47317((params, output) -> {
                output.method_45421(ModBlocks.PLAIN_CONSTRUCTION_BARRIER);
                output.method_45421(ModBlocks.MESH_CONSTRUCTION_BARRIER);
                output.method_45421(ModBlocks.PLAIN_CONSTRUCTION_BARRIER_CORNER);
                output.method_45421(ModBlocks.MESH_CONSTRUCTION_BARRIER_CORNER);
                output.method_45421(ModBlocks.ROAD_SIGN);
                output.method_45421(ModBlocks.TACTILE_PAVING);
            })
            .method_47324();

    public static void initialize() {
        class_2378.method_39197(class_7923.field_44687, ROAD_FACILITIES_CREATIVE_TAB_KEY, ROAD_FACILITIES_CREATIVE_TAB);
    }
}
