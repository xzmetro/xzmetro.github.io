package org.xzmetro.mod.sound;

import static org.xzmetro.mod.util.Constants.getId;

import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_7923;

public class ModSounds {
    public static final class_3414 TRAIN_DEPARTURE_BELL_SOUND = register(ModSoundPaths.TRAIN_DEPARTURE_BELL_SOUND_PATH);

    public static class_3414 register(String name) {
        class_2960 id = getId(name);
        return class_2378.method_10230(class_7923.field_41172, id, class_3414.method_47908(id));
    }

    public static void initialize() {
    }
}
